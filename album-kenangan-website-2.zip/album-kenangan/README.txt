# ALBUM KENANGAN

Website album foto responsif untuk HP dan komputer.

## Isi folder
- index.html = halaman website
- style.css = desain
- script.js = slideshow, countdown, zoom, musik, animasi
- foto/ = masukkan foto kamu di sini
- musik.mp3 = masukkan musik milikmu di sini

## Cara menggunakan
1. Ganti foto1.jpg sampai foto6.jpg dengan foto kamu.
2. Jika ingin musik, masukkan file bernama `musik.mp3` di folder utama.
3. Buka `script.js`.
4. Cari:
   const memoryDate = "2026-12-31T00:00:00";
   lalu ganti dengan tanggal kenanganmu.
5. Klik dua kali `index.html` untuk membuka website di Chrome.

Catatan:
- Nama file foto harus sesuai dengan yang ditulis di index.html.
- Browser dapat memblokir autoplay musik. Tekan tombol ♫ setelah halaman dibuka.
- Untuk dipublikasikan ke internet, folder ini bisa diunggah ke layanan hosting statis seperti GitHub Pages.
